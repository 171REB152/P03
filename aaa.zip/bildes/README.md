# RTR108P01
P04
P01 Darba mērķi:
•Veikt elektriskās ķēdes sprieguma dalītāja aprēķinus teorētiski.
•Apgūt elektriskās ķēdes sprieguma dalītāja simulāciju izmantojot gEDA programmas.
•Apgūt elektriskās ķēdes sprieguma dalītāja simulāciju QUCS vidē.

Pirmajā praktiskā darba bija iepazīšanas ar ķēžu simulātoriem.
Viss iet labi.
